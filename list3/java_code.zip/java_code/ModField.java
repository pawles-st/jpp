public interface ModField {
	long characteristic = 1234567891;
	ModField add(final ModField rhs);
	ModField sub(final ModField rhs);
	ModField mul(final ModField rhs);
	ModField div(final ModField rhs);
	ModField inverse();
	static long getCharacteristic() {
		return characteristic;
	}
	long getValue();
	void setValue(final long value);
}
