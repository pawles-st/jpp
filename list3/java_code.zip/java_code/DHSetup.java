import java.util.ArrayList;
import java.util.Random;
import java.util.function.Function;

public class DHSetup <T extends ModField & Comparable<T>> {
	public DHSetup(Function<Long, T> constructor) {
		this.constructor = constructor;

		long q = T.characteristic - 1;
		ArrayList<Long> primeDivisors = this.findPrimeDivisors(q);
		
		Random rng = new Random();
		T g;
		do {
			g = this.constructor.apply(rng.nextLong(T.characteristic - 3) + 2);
		} while (!this.isGenerator(g, primeDivisors));
	}

	public T power(T a, long b) {
		T pow = constructor.apply(a.getValue());
		
	}

	private Function<Long, T> constructor;
	private T generator;

	private ArrayList<Long> findPrimeDivisors(long q) {
		ArrayList<Long> divisors = new ArrayList<Long>();
		for (long x = 2; q > 1; ++x) {
			if (q % x == 0) {
				divisors.add(x);
				do {
					q /= x;
				} while (q % x == 0);
			}
		}
		return divisors;
	}

	private boolean isGenerator(final T g, final ArrayList<Long> divisors) {
		for (long p : divisors) {
			if (this.power(g, (T.characteristic - 1) / p).compareTo(this.constructor.apply(1L)) == 0) {
				return false;
			}
		}
		return true;
	}
}
